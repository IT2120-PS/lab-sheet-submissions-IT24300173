getwd()
setwd("C:/Users/user/Desktop/IT24300173")
getwd()
#Q1
#Part01
#Binomial Distribution
# n=50 and p=0.85

#Part02
1 - pbinom(46,50,0.85,lower.tail = TRUE)
#OR
pbinom(46,50,0.85,lower.tail = FALSE)

#Q2
#Part01
#Number of customer calls receive per hour

#Part02
#Poisson Distribution
#Random variable x has poisson distribution with lambda=12

#Part03
dpois(15,12)


