getwd()
setwd("C:/Users/IT24300173/Desktop/IT24300173")
getwd()

data<-read.table("Exercise.txt",header=TRUE,sep=" ")
fix(data)
attach(data)

str(branch_data)
str(data)

boxplot(Sales_X1,main="Box plot for sales",outline=TRUE,outpch=8,horizontal=TRUE)

summary(Advertising_X2)
IQR(Advertising_X2)

get.outliers<- function(z)
  q1 <- quantile(z)[2]
q1 <- quantile(z)[4]